/*************************************************************************
*   Programming Assignment 1: Linux Commands Matching Game
*   Mason Hatch
*   CptS 223, Fall 2020
**************************************************************************/
#include "matching.h"
using namespace std;

int main()
{
    //Load in csv files
    fstream commandFile;
    commandFile.open("commands.csv", ios::in);
    if(!commandFile.is_open())
    {
        cout << "\ncommands.csv read error\n";
        return 1;
    }
    linkedList<commandData> commandList;
    string lineIn;
    vector<string> v; 
    commandData loadCommand;
    while(getline(commandFile, lineIn))
    {
        stringstream ss(lineIn); 
        while (ss.good()) { 
            string substr; 
            getline(ss, substr, ','); 
            v.push_back(substr); 
        }  
        loadCommand.command = v[0];
        loadCommand.description = v[1];
        commandList.insertAtFront(loadCommand);
    }
    commandFile.close();

    fstream profileFile;
    profileFile.open("profiles.csv", ios::in);
    if(!profileFile.is_open())
    {
        cout << "\nprofiles.csv read error\n";
        return 1;
    }
    linkedList<profileData> profileList;
    profileData loadprofile;
    while(getline(profileFile, lineIn))
    {
        stringstream ss(lineIn); 
        while (ss.good()) { 
            string substr; 
            getline(ss, substr, ','); 
            v.push_back(substr); 
        }  
        loadprofile.name = v[0];
        loadprofile.points = v[1];
        profileList.insertAtFront(loadprofile);
    }
    profileFile.close();
    

    //Main menu
    int menuChoice = 0;
    while(menuChoice != 6)
    {
        menuChoice = 0;
        while(menuChoice > 6 || menuChoice < 1)
        {
            system("clear");
            cout << "\n    Linux Command Matching Game\n\n\t1. Game Rules\n\t2. Play Game\n\t3. Load Previous Game\n\t4. Add Command\n\t5. Remove Command\n\t6. Exit\n\n\n Enter the number of your choice: ";
            cin >> menuChoice;
        }
        string temp;
        commandData addCommand;
        switch(menuChoice)
        {
            case 1: //Game Rules
                system("clear");
                cout << "\n\t\t\t\t\t\tGame Rules\n\n  To play, select Play Game from the main menu and select the number of commands you'd like to match.\n As each command shows up on screen, type the number of the matching description of the shown command\n and hit Enter to submit. You will gain 1 point for correct answers.\n\nPress enter to continue.\n";
                getchar();
                getchar();
                break;
            case 2: //Play Game
                break;
            case 3: //Load Game
                break;
            case 4: //Add Command
                system("clear");
                cout << "\n Enter the command to add: ";
                cin >> addCommand.command;
                cout << "\n Enter a description of the command: ";
                getchar();
                getline(cin, addCommand.description);
                commandList.insertAtFront(addCommand);
                break;
            case 5: //Remove Command
                break;
            case 6: //Exit
                break;
            default: //This should never execute
                cout << "ERROR 404 CHOICE NOT FOUND\nWHY/HOW DID YOU DO THAT?\n\n";
                return 1;
        }
    }

    //Upon exit:

    ofstream commandFileOut("commands.csv");
    if(!commandFileOut.is_open())
    {
        cout << "\ncommands.csv open error\n";
        return 1;
    }
    commandFileOut << commandList;
    commandFileOut.close();



    return 0;
}