/*************************************************************************
*   Programming Assignment 1: Linux Commands Matching Game
*   Mason Hatch
*   CptS 223, Fall 2020
**************************************************************************/
#include "matching.h"

using namespace std;

ostream& operator<<(ostream& lhs, const commandData& rhs)
{
    return lhs << rhs.command << "," << rhs.description << endl;
}

ostream& operator<<(ostream& lhs, const profileData& rhs)
{
    return lhs << rhs.name << "," << rhs.points << endl;
}

ostream& operator<<(ostream& lhs, linkedList<commandData>& rhs)
{
    Node<commandData> *curr = rhs.getHead();
        while (curr != NULL)
        {
            lhs << curr->getData();
            curr = curr->getNext();
        }
}
