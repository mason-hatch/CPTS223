#ifndef MATCHING_H
#define MATCHING_H

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <sstream>

using namespace std;

struct commandData
{
    string command;
    string description;
};

struct profileData
{
    string name;
    string points;
};

template <class T> class Node
{
    T data;
    Node<T> *next;

public:

    Node()
    {
        this->next = NULL;
    }

    Node(T data)
    {
        this->data = data;
        this->next = NULL;
    }

    Node(T data, Node *next)
    {
        this->data = data;
        this->next = next;
    }

    T getData()
    {
        return data;
    }

    Node * getNext()
    {
        return next;
    }

    void setData(T data)
    {
        this->data = data;
    }

    void setNext(Node *next)
    {
        this->next = next;
    }
};

template <class T> class linkedList
{
    Node<T> *head;

public:

    linkedList()
    {
        head = NULL;
    }

    ~linkedList()
    {
        
    }

    void insertAtFront(T data)
    {
        if(this->head = NULL)
        {
            head = new Node<T>;
            head->setData(data);
        }
        else
        {
            Node<T> *temp = this->head;
            Node<T> *newNode = new Node<T>;
            this->head = newNode;
            this->head->setData(data);
            this->head->setNext(temp);
        }
        
    }

    Node<T> *getHead()
    {
        return this->head;
    }

};

ostream& operator<<(ostream& lhs, const commandData& rhs);

ostream& operator<<(ostream& lhs, const profileData& rhs);

ostream& operator<<(ostream& lhs, linkedList<commandData>& rhs);

#endif